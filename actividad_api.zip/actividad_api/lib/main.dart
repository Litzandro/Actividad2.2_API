import 'dart:convert';
import 'dart:io';
import 'package:actividad_api/types/photos.dart';
import 'package:flutter/foundation.dart';
import "package:http/http.dart" as http;

void main() async {
  try {
    List<Map<String, dynamic>> photos = await fetchPhotos();
    for (var photo in photos) {
      if (kDebugMode) {
        print(photo['url']);
      }
    }
  } catch (error) {
    if (kDebugMode) {
      print('Error al obtener las fotos: $error');
    }
  }
}

Future<List<Map<String, dynamic>>> fetchPhotos() async {
  final response =
      await http.get(Uri.parse('https://jsonplaceholder.typicode.com/photos'));

  if (response.statusCode == 200) {
    List<dynamic> data = json.decode(response.body);
    List<Map<String, dynamic>> photos = List<Map<String, dynamic>>.from(data);
    return photos;
  } else {
    throw HttpException('Error al obtener las fotos: ${response.reasonPhrase}');
  }
}
